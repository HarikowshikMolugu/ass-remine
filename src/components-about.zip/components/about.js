import React from "react";
import Contactus from './contactus';
import location from "./location.png";


function about(){
    return(
        <div>
        <div className="head">
        <p align="center" >About   <b>Infusion Techno Solutions</b></p>
        </div>
        <div >
        <ul class="topnav" type="none">
        <li><a href="#about-out">ABOUT</a></li>
        <li><a href="#footer">CONTACT US</a></li>
        <li><a href="#contact-out">MEET US</a></li>
        </ul>
        </div>
        <div id="about-out">
            <div id="about-content">
            <div id="about-content1">
        <p id="about-content1-1"><b>Some words about us</b></p>
        <p id="about-content1-2"><b>Infussion</b> is a creative digital agency headquartered in <b>Vizianagaram, Andhra pradesh, India</b>. We specialise in Mobile & Web Application development, Design & Branding and general IT consultancy.<br></br><br></br>
We have a proven history of creating online success for global organisations via our suite of services offerings. <b> We help define your goals, create effective strategies, build easy to use applications, and design award-winning systems that communicates the desired message.</b><br></br><br></br>
Our process unites talent & passion with discipline. Our competitive prices ensures that projects are executed within budget and on time. This allows for true client-to-project transparency and a streamlined workflow from concept to execution.</p>
        </div>
        <div id="about-content2">
            <fieldset id="fs1">
                <legend><p id="about-content2-1"><b>We are proud to work with</b></p></legend>
            </fieldset>

        </div>
            </div>
       
        </div>
        <div className="lines1">
            <div id="line1">
            <p id="main-line1" align="center">Digital expertise for Business growth</p>
            <p id="sub-line1" align="center">Your one-stop international brand management, design and consultancy agency</p>
            </div>
            
        </div>
        <div id="content2-out">
            <div id="content2-content">
            <div id="content2-content1">
                <p id="content2-content1-1">
                We pride ourselves on the quality and affordability of our work, as such our applications are feature rich and competitively priced, giving you the best in both cost and quality. Our projects are run at fixed prices for complete security and peace of mind. <b>Here are some more reasons why you should choose Infusion for your next project.</b>
                </p>
                <div id="content2-content1-2">
                    <div id="content2-content1-2-1">
                        <p>Complimentary consultation</p>
                        <p>Unbiased advisory services</p>
                        <p>Unlimited design samples</p>
                    </div>
                    <div id="content2-content1-2-2">
                        
                        <p>Experienced working within various sectors/industries</p>
                        <p>An national portfolio</p>
                        <p>User friendly</p>
                    </div>
                </div>
            </div>
            </div>
            

        </div>
        <div className="lines2">
            <div id="line2">
            <p id="main-line2" align="center">QUALITY ASSURANCE</p>
        <p id="sub-line2-1" align="center">With a commitment to quality, an in depth knowledge of interactive best practices and a
        structured proven process – our company delivers excellence time and time again.</p>
            </div>
        
        </div>
        <div>
        <Contactus></Contactus>
        </div>
        <div id="map-det">
        
          
           <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60678.16449990618!2d83.3681992656825!3d18.099990689638048!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a3be517fcf0885f%3A0xe85104bb5f291d8d!2sVizianagaram%2C%20Andhra%20Pradesh!5e0!3m2!1sen!2sin!4v1676029608685!5m2!1sen!2sin"
           
           
            allowfullscreen=""
            loading="lazy"
          ></iframe>
        
            
        
        <div id="map-content">
          <div id="map-content-1">Meet us at</div>
          <div id="map-content-2">
            <div><img src={location} alt="logo" id="icon"></img></div>
            <div><p id="address">Vizianagaram</p></div>

          </div>
         
        </div>
        </div>
        <div id="bottom-name"><p align="center"><b>Infussion Techno Solutions</b></p></div>
       
    </div>
        
    
    )   
}
export default about;